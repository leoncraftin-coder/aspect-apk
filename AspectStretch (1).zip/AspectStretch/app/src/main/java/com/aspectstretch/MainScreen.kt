package com.aspectstretch

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun Context.hasSecureSettings(): Boolean =
    checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var info by remember { mutableStateOf<Wm.Info?>(null) }
    var selected by remember { mutableStateOf<Ratio?>(PRESETS[0]) } // null = свой формат
    var customA by remember { mutableStateOf("16") }
    var customB by remember { mutableStateOf("10") }
    var keepDpi by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var previous by remember { mutableStateOf<Wm.Info?>(null) } // не null, пока открыто окно подтверждения
    var hasPermission by remember { mutableStateOf(ctx.hasSecureSettings()) }

    fun refresh() {
        scope.launch {
            info = withContext(Dispatchers.IO) { Wm.info() }
            hasPermission = ctx.hasSecureSettings()
        }
    }
    LaunchedEffect(Unit) { refresh() }

    val ratio: Ratio? = selected ?: run {
        val a = customA.toIntOrNull()
        val b = customB.toIntOrNull()
        if (a != null && b != null && a in 1..100 && b in 1..100) Ratio(a, b) else null
    }
    val ratioTooExtreme = ratio != null && ratio.value > AspectMath.MAX_RATIO
    val validRatio = if (ratioTooExtreme) null else ratio

    val current = info
    val target = if (current != null && validRatio != null) AspectMath.target(current.physical, validRatio) else null
    val targetDpi = if (keepDpi && current?.physicalDpi != null && target != null)
        AspectMath.scaledDensity(current.physicalDpi, current.physical, target) else null

    fun applyFormat() {
        val t = target ?: return
        val before = current ?: return
        scope.launch {
            busy = true
            message = null
            val r = withContext(Dispatchers.IO) { Wm.apply(t, targetDpi) }
            if (r.ok) {
                previous = before
            } else {
                message = "Не удалось применить: ${r.text.ifBlank { "нет доступа" }}. Выдайте разрешение (см. ниже)."
            }
            refresh()
            busy = false
        }
    }

    fun resetFormat() {
        scope.launch {
            busy = true
            val r = withContext(Dispatchers.IO) { Wm.reset() }
            message = if (r.ok) "Экран вернулся к родному формату" else "Не удалось сбросить: ${r.text}"
            refresh()
            busy = false
        }
    }

    previous?.let { prev ->
        ConfirmDialog(
            onKeep = { previous = null; message = "Формат сохранён" },
            onRevert = {
                previous = null
                scope.launch {
                    withContext(Dispatchers.IO) { Wm.restore(prev) }
                    message = "Прежний формат возвращён"
                    refresh()
                }
            },
        )
    }

    Column(
        modifier = Modifier
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Растяжка экрана", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)

        // Текущее состояние
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (current == null) {
                    Text("Читаю параметры экрана…")
                } else {
                    Text("Родной экран: ${current.physical}", fontFamily = FontFamily.Monospace)
                    Text("Сейчас: ${current.current}", fontFamily = FontFamily.Monospace)
                    current.currentDpi?.let { Text("Плотность: $it dpi", fontFamily = FontFamily.Monospace) }
                }
            }
        }

        // Выбор формата
        Text("Формат", style = MaterialTheme.typography.titleMedium)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            PRESETS.forEach { p ->
                FilterChip(
                    selected = selected == p,
                    onClick = { selected = p },
                    label = { Text(p.label) },
                )
            }
            FilterChip(
                selected = selected == null,
                onClick = { selected = null },
                label = { Text("Свой") },
            )
        }

        if (selected == null) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = customA,
                    onValueChange = { customA = it.filter(Char::isDigit).take(3) },
                    label = { Text("Длинная сторона") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
                Text(":", fontSize = 24.sp)
                OutlinedTextField(
                    value = customB,
                    onValueChange = { customB = it.filter(Char::isDigit).take(3) },
                    label = { Text("Короткая сторона") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
            }
            if (ratioTooExtreme) {
                Text(
                    "Слишком вытянутый формат. Максимум ${AspectMath.MAX_RATIO.toInt()}:1.",
                    color = MaterialTheme.colorScheme.error,
                )
            }
        }

        // Предпросмотр
        if (target != null && current != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .height(120.dp)
                        .aspectRatio(target.w.toFloat() / target.h),
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth().height(120.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    ) {}
                }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Будет: $target", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium)
                    targetDpi?.let { Text("$it dpi", fontFamily = FontFamily.Monospace) }
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Switch(checked = keepDpi, onCheckedChange = { keepDpi = it })
            Column(Modifier.weight(1f)) {
                Text("Сохранять размер интерфейса")
                Text(
                    "Подбирает dpi, чтобы кнопки и текст не менялись по размеру",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Button(
            onClick = { applyFormat() },
            enabled = target != null && !busy && previous == null,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Применить") }

        OutlinedButton(
            onClick = { resetFormat() },
            enabled = !busy && previous == null,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Сбросить к родному формату") }

        message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }

        if (!hasPermission) SetupCard(ctx.packageName) { clipboard.setText(AnnotatedString(it)) }
    }
}

@Composable
private fun SetupCard(pkg: String, onCopy: (String) -> Unit) {
    val cmd = "adb shell pm grant $pkg android.permission.WRITE_SECURE_SETTINGS"
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Нужно разрешение", style = MaterialTheme.typography.titleMedium)
            Text(
                "Смена формата экрана требует особого разрешения. Его выдают один раз. " +
                    "Включите отладку по USB, подключите телефон к компьютеру и выполните команду:",
            )
            Text(cmd, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            TextButton(onClick = { onCopy(cmd) }) { Text("Скопировать команду") }
            Text(
                "Если на телефоне есть root, приложение само запросит доступ при первом применении формата.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ConfirmDialog(onKeep: () -> Unit, onRevert: () -> Unit) {
    var left by remember { mutableIntStateOf(15) }
    LaunchedEffect(Unit) {
        while (left > 0) {
            delay(1000)
            left--
        }
        onRevert()
    }
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Оставить этот формат?") },
        text = { Text("Если ничего не нажать, прежний формат вернётся через $left с.") },
        confirmButton = { Button(onClick = onKeep) { Text("Оставить") } },
        dismissButton = { TextButton(onClick = onRevert) { Text("Вернуть") } },
    )
}
