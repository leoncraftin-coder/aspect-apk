package com.aspectstretch

import java.util.concurrent.TimeUnit

/**
 * Обёртка над командами `wm size` и `wm density`.
 *
 * Порядок попыток:
 * 1. Напрямую из процесса приложения. Работает, если выдано WRITE_SECURE_SETTINGS.
 * 2. Через `su`, если на телефоне есть root.
 */
object Wm {
    data class Out(val code: Int, val text: String) {
        val ok: Boolean
            get() = code == 0 &&
                !text.contains("exception", ignoreCase = true) &&
                !text.contains("denied", ignoreCase = true) &&
                !text.contains("not found", ignoreCase = true)
    }

    data class Info(
        val physical: Size,
        val override: Size?,
        val physicalDpi: Int?,
        val overrideDpi: Int?,
    ) {
        val current: Size get() = override ?: physical
        val currentDpi: Int? get() = overrideDpi ?: physicalDpi
    }

    private fun exec(args: List<String>): Out = try {
        val p = ProcessBuilder(args).redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().readText().trim()
        if (p.waitFor(8, TimeUnit.SECONDS)) {
            Out(p.exitValue(), text)
        } else {
            p.destroyForcibly()
            Out(-1, "timeout")
        }
    } catch (e: Exception) {
        Out(-1, e.message ?: "error")
    }

    private fun direct(cmd: String) = exec(listOf("sh", "-c", cmd))
    private fun root(cmd: String) = exec(listOf("su", "-c", cmd))

    /** Выполняет команду напрямую, при неудаче через root. Возвращает ошибку прямого запуска, если обе попытки не удались. */
    fun run(cmd: String): Out {
        val d = direct(cmd)
        if (d.ok) return d
        val r = root(cmd)
        return if (r.ok) r else d
    }

    fun info(): Info? {
        val size = direct("wm size").text
        val physical = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(size)
            ?.let { Size(it.groupValues[1].toInt(), it.groupValues[2].toInt()) }
            ?: return null
        val override = Regex("Override size:\\s*(\\d+)x(\\d+)").find(size)
            ?.let { Size(it.groupValues[1].toInt(), it.groupValues[2].toInt()) }

        val density = direct("wm density").text
        val physicalDpi = Regex("Physical density:\\s*(\\d+)").find(density)?.groupValues?.get(1)?.toInt()
        val overrideDpi = Regex("Override density:\\s*(\\d+)").find(density)?.groupValues?.get(1)?.toInt()

        return Info(physical, override, physicalDpi, overrideDpi)
    }

    fun apply(size: Size, dpi: Int?): Out {
        val r = run("wm size $size")
        if (!r.ok) return r
        return if (dpi != null) run("wm density $dpi") else r
    }

    fun reset(): Out {
        val r = run("wm size reset")
        if (!r.ok) return r
        return run("wm density reset")
    }

    /** Возвращает экран в состояние, которое было до применения формата. */
    fun restore(prev: Info): Out {
        val s = if (prev.override == null) run("wm size reset") else run("wm size ${prev.override}")
        if (!s.ok) return s
        return if (prev.overrideDpi == null) run("wm density reset") else run("wm density ${prev.overrideDpi}")
    }
}
