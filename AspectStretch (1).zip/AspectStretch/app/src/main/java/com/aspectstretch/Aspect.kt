package com.aspectstretch

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class Ratio(val a: Int, val b: Int) {
    val label: String get() = "$a:$b"

    /** Отношение длинной стороны к короткой, всегда >= 1. */
    val value: Double get() = max(a, b).toDouble() / min(a, b)
}

data class Size(val w: Int, val h: Int) {
    override fun toString(): String = "${w}x$h"
}

val PRESETS = listOf(
    Ratio(16, 10),
    Ratio(4, 3),
    Ratio(5, 4),
    Ratio(3, 2),
    Ratio(16, 9),
    Ratio(1, 1),
    Ratio(2, 1),
    Ratio(21, 9),
)

object AspectMath {
    /** Самый вытянутый формат, который приложение разрешает (защита от нерабочего экрана). */
    const val MAX_RATIO = 4.0

    /**
     * Размер для `wm size` в естественной ориентации экрана (у телефона это портрет).
     * Система растягивает картинку на весь физический экран, поэтому изображение
     * получается растянутым под выбранные пропорции.
     *
     * Если выбранный формат менее вытянут, чем сам экран, длинная сторона уменьшается.
     * Если более вытянут, уменьшается короткая сторона.
     */
    fun target(physical: Size, ratio: Ratio): Size {
        val big = max(physical.w, physical.h)
        val small = min(physical.w, physical.h)
        val physicalRatio = big.toDouble() / small
        val r = ratio.value

        val newBig: Int
        val newSmall: Int
        if (r < physicalRatio) {
            newBig = even(small * r)
            newSmall = small
        } else {
            newBig = big
            newSmall = even(big / r)
        }
        return if (physical.w <= physical.h) Size(newSmall, newBig) else Size(newBig, newSmall)
    }

    /** DPI, при котором ширина интерфейса в dp остаётся прежней. */
    fun scaledDensity(physicalDpi: Int, physical: Size, target: Size): Int =
        (physicalDpi * target.w / physical.w.toDouble()).roundToInt().coerceAtLeast(120)

    private fun even(v: Double): Int {
        val n = v.roundToInt()
        return if (n % 2 == 0) n else n + 1
    }
}
